""" @brief  A module for solving a frequency j yielded by the quantum part of
            Shor's order-finding algorithm for the order r. """

B_DEFAULT_SOLVE = 1000;