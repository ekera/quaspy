""" @brief  A module for internal classes and functions used by the functions in
            the parent module for solving a frequency j yielded by the quantum
            part of Shor's order-finding algorithm for the order r. """