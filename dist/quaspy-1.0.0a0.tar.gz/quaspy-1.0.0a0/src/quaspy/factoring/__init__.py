""" @brief  A module for factoring integers. """
