""" @brief  A module for internal classes and functions used by the functions in
            the parent module for factoring N completely. """