""" @brief  A module for post-processing the output from quantum order-finding
            algorithms.
"""
