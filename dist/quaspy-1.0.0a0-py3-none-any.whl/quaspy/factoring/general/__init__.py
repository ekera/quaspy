""" @brief  A module for factoring general integers via order finding. """
