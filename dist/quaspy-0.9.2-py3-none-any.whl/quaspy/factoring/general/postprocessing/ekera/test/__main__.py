from . import test_all;

test_all();